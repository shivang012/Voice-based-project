# voice-based-project
. The query for the assistant can be manipulated as per the user’s need.  Speech recognition is the process of converting audio into text. 

This is commonly used in voice assistants like Alexa, Siri, etc. Python provides an API called SpeechRecognition to allow us to convert audio into text for further processing.


##CONTRIBUTOR-
PAYAL SINGH
ABHIMAN GAUTAM
ARCHIT KUMAR
SHREYASH JAISWAL
